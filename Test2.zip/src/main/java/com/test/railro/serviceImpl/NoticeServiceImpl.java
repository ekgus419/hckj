package com.test.railro.serviceImpl;

import java.util.List;

import com.test.railro.dto.Notice;
import com.test.railro.service.NoticeService;

public class NoticeServiceImpl implements NoticeService {

	public int getTotalBoardListCount() {
		
		return 0;
	}
	
	public List<Notice> noticeList() {
		
		NoticeMapper
	}
	
}
