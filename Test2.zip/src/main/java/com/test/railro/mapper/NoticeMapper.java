package com.test.railro.mapper;

import java.util.List;

import com.test.railro.dto.Notice;

public interface NoticeMapper {

	public List<Notice> noticeList();
	
}
